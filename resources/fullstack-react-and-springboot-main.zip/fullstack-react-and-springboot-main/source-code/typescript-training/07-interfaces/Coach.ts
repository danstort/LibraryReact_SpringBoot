export interface Coach {

    getDailyWorkout(): string;
    
}